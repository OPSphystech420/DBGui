//
//  MariaDB.h
//  MariaDB
//
//  Created by Kyle Hankinson on 8/11/17.
//  Updated by Yuri (https://yuriydev.com)
//  Copyright © 2017 Kyle Hankinson. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MariaDB.
FOUNDATION_EXPORT double MariaDBVersionNumber;

//! Project version string for MariaDB.
FOUNDATION_EXPORT const unsigned char MariaDBVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MariaDB/PublicHeader.h>
#import "mysql.h"
#import "MariaDBClient.h"
#import "MariaDBResultSet.h"
